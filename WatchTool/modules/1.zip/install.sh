SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=false
print_modname() {
  ui_print "============================"
  ui_print "-  正在安装YelvtiOS "
  ui_print "-  By MCBUG087 "
  ui_print "============================"
}
on_install() {
  ui_print "- 正在释放文件"
PACKAGE_NAME=com.sogou.ime.wear
# 检测应用是否已安装
isInstalled=$(pm list packages -s | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 卸载应用：$PACKAGE_NAME"
    pm uninstall --user 0 ${PACKAGE_NAME}
    ui_print "- 应用 $PACKAGE_NAME 卸载完成."
else
    ui_print "- 应用 $PACKAGE_NAME 未安装."
fi
PACKAGE_NAME=com.google.android.inputmethod.latin
# 检测应用是否已安装
isInstalled=$(pm list packages | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 应用 GBoard 已安装"
else
    ui_print "- 应用 GBoard 未安装."
    ui_print "- 正在下载安装包..."
    curl -o ${0%/*}/gboard.apk https://mcbug087.eu.org/WatchTool/apks/13.apk
    ui_print "- 正在安装..."
    pm install -r -t -d ${0%/*}/gboard.apk
fi
PACKAGE_NAME=com.barkbox
# 检测应用是否已安装
isInstalled=$(pm list packages | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 应用 Barkbox 已安装"
else
    ui_print "- 应用 Barkbox 未安装."
    ui_print "- 正在下载安装包..."
    curl -o ${0%/*}/barkbox.apk https://mcbug087.eu.org/WatchTool/apks/4.apk
    ui_print "- 正在安装..."
    pm install -r -t -d ${0%/*}/barkbox.apk
fi
PACKAGE_NAME=moe.shizuku.privileged.api
# 检测应用是否已安装
isInstalled=$(pm list packages | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 应用 Shizuku 已安装"
else
    ui_print "- 应用 Shizuku 未安装."
    ui_print "- 正在下载安装包..."
    curl -o ${0%/*}/shizuku.apk https://mcbug087.eu.org/WatchTool/apks/26.apk
    ui_print "- 正在安装..."
    pm install -r -t -d ${0%/*}/shizuku.apk
fi
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}