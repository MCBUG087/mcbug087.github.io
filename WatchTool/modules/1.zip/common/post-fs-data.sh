#!/data/adb/magisk/busybox sh
MODDIR=${0%/*}
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
sleep 5
done
setprop persist.service.adb.enable 1
setprop persist.service.debuggable 1
setprop persist.adb.tcp.port 5555
setprop service.adb.tcp.port 5555
setprop ctl.restart adbd
su -c sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh